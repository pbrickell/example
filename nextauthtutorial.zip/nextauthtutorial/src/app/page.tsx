import { options } from "./api/auth/[...nextauth]/options";
import { getServerSession } from "next-auth";

export default async function Home() {
  const session = await getServerSession(options);
  return (
    <>
      {session ? (
        <div>Session {session.user?.email}</div>
      ) : (
        <div>No session</div>
      )}
    </>
  );
}
